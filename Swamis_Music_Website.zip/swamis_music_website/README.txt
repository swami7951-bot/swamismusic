SWAMIS MUSIC WEBSITE
====================

Files:
- index.html: Complete responsive one-page website.
- README.txt: These instructions.

PUBLISH FREE:
1. Open https://app.netlify.com/drop in your browser.
2. Upload the whole "swamis_music_website" folder (or unzip the ZIP first, then upload the folder).
3. Netlify will give you a shareable website URL ending in netlify.app.
4. Keep that URL and send it to clients.
5. For a custom domain such as swamismusic.in, you will need to register/pay for the domain separately.

The order form is embedded from your supplied Google Forms URL. Form responses continue to go to your existing Google Form.
The studio hero image is loaded from Unsplash, so the published site needs an internet connection to display it.

IMPORTANT:
- The package prices and benefits currently displayed are copied from the Google Form you supplied.
- Check the site on mobile after publishing, and test one form submission before sending it to clients.
